#import "Toyota.h"
#import "Car.h"

@implementation Toyota

-(id)init

{
    self = [super init];
    
    if (Car)
    {
        [self initHelper];
    }
    return self;
}


@end
