#import "Car.h"

@implementation Car


-(void) drive

{
    NSLog(@"I'm driving a %@", self.model);
}

- (id)initWithModel:(NSString *)model

{
    self = [super init];
    
    if(self)
    
    {
        _model = [model copy];
    }
    
    return self;
    
}

- (id)init

{
    return [self initWithModel:_model];
}


@end

