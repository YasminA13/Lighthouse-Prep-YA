#import "Car.h"

@interface Toyota : Car

@end
