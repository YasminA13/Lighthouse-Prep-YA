#import <Foundation/Foundation.h>

@interface Car : NSObject

@property NSString *model;

-(void)drive;



@end


