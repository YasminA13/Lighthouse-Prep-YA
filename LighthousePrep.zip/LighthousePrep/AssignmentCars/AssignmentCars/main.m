
#import <Foundation/Foundation.h>
#import "Car.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool
    
    {
        Car *Toyota = [[Car alloc] initWithModel:@"Prius"];
        
        Car *Nissan = [[Car alloc] initWithModel:@"Rouge"];
    }
    return 0;
}
