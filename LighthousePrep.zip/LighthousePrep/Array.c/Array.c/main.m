#import <Foundation/Foundation.h>

int main()
{
    

{
    
    NSArray  *numbers = @[@544, @13, @2016, @27, @54, @1887];
    
    NSSet *numberSet = [NSSet setWithArray:numbers];
    
    NSArray *sortedNumbers = [[numberSet allObjects] sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"self" ascending:!YES] ]];
    
    NSNumber *Highest;
    
    if ([sortedNumbers count] > 0)
    {
        Highest = sortedNumbers[0];
    }
    
    NSLog(@"The highest number in the array is %@.", Highest);
}
    return 0;
}